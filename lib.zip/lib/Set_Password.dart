import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:eshop/Forget_Password.dart';
import 'package:eshop/Helper/String.dart';
import 'package:eshop/Login.dart';
import 'package:eshop/Verify_Otp.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart';
import 'Helper/Color.dart';
import 'Helper/Constant.dart';
import 'Helper/Session.dart';
import 'Home.dart';
import 'SignUp.dart';

class SetPass extends StatefulWidget {
  final String mobileNumber;
  SetPass({
    Key key,
    @required this.mobileNumber,
  })  : assert(mobileNumber != null),
        super(key: key);

  @override
  _LoginPageState createState() => new _LoginPageState();
}

class _LoginPageState extends State<SetPass> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final confirmpassController = TextEditingController();
  final passwordController = TextEditingController();
  bool _isLoading = false;
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  String password,comfirmpass;





  void validateAndSubmit() async {
    if (validateAndSave()) {
      setState(() {
        _isLoading = true;
      });
      checkNetwork();
    }
  }
  Future<void> checkNetwork() async {
    bool avail = await isNetworkAvailable();
    if (avail) {
      getResetPass();

    } else {
      setSnackbar(internetMsg);
      setState(() {
        _isLoading = false;
      });
    }
  }


  bool validateAndSave() {
    final form = _formkey.currentState;
    if (form.validate()) {
      form.save();
      return true;
    }
    return false;
  }

  bool resetAndClear()
  {
    _formkey.currentState.reset();
    confirmpassController.clear();
    passwordController.clear();
  }

  setSnackbar(String msg) {
    _scaffoldKey.currentState.showSnackBar(new SnackBar(
      content: new Text(
        msg,
        textAlign: TextAlign.center,
        style: TextStyle(color:primary),
      ),
      backgroundColor: Colors.white,
      elevation: 1.0,
    ));
  }


  Future<void> getResetPass() async {
    final phone=widget.mobileNumber;
    print("Mobile number *******$phone");
    try {
      var data = {MOBILENO:widget.mobileNumber,NEWPASS: password};
      Response response =
      await post(getResetPassApi, body: data, headers: headers)
          .timeout(Duration(seconds: timeOut));

      var getdata = json.decode(response.body);
      print('response***resetPass**$headers***${response.body.toString()}');
      bool error = getdata["error"];
      String msg = getdata["message"];
      if (!error) {
        setSnackbar("Password Update Successfully! Please Login");
        Future.delayed(Duration(seconds: 1)).then((_) {
          Navigator.of(context)
              .push(MaterialPageRoute(
            builder: (BuildContext context) => Login(),
          ))
              .then((_) => resetAndClear());
        });
      } else {
        setSnackbar(msg);
      }
      setState(() {});
    } on TimeoutException catch (_) {
      setSnackbar(somethingMSg);
    }
  }


  subLogo()
  {
    return Container(
      padding: EdgeInsets.only(top: 150.0),
      child: Center(
        child: new Image.asset('assets/images/sublogo.png',
            fit: BoxFit.fill),
      ),
    );
  }



  forgotpassTxt()
  {
    double width = MediaQuery.of(context).size.width ;
    return  Container(
        width: width,
        padding: EdgeInsets.only(top: 25.0),
        child:Center(
          child: new Text(FORGOT_PASSWORDTITILE,style: Theme.of(context).textTheme.headline6.copyWith(color: lightblack,
              fontWeight: FontWeight.bold),),
        ));

  }



  setPass()
  {
    return Container(
      padding: EdgeInsets.only(left: 20.0,
          right: 20.0,
          top: 20.0),
      child: TextFormField(
        keyboardType: TextInputType.text,
        obscureText: true,
        controller: passwordController,
        validator: validatePass,
        onSaved: (String value) {
          password = value;
        },
        decoration: InputDecoration(
            prefixIcon: Icon(Icons.lock_outline),
            hintText: 'Password',
            contentPadding:
            EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(
                    10.0)
            )
        ),
      ),
    );
  }

  setConfirmpss()
  {
    return Container(
      padding: EdgeInsets.only(left: 20.0,
          right: 20.0,
          top: 30.0),
      child: Center(
        child: TextFormField(
          keyboardType: TextInputType.text,
          obscureText: true,
          controller: confirmpassController,
          validator: validatePass,
          onSaved: (String value)
          {
            comfirmpass = value;
            if(value!=password)
              {
                setSnackbar("Confirm Password Not match");
              }
            },
          decoration: InputDecoration(
              prefixIcon: Icon(Icons.lock_outline),
              hintText: 'Confirm Password',
              contentPadding:
              EdgeInsets.fromLTRB(
                  10.0, 10.0, 10.0, 10.0),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                      10.0)

              )
          ),
        ),
      ),
    );
  }



  setPassBtn()
  {
    double width = MediaQuery.of(context).size.width;

    return Container(
      padding: EdgeInsets.only(bottom: 30.0,
          left: 20.0,
          right: 20.0,
          top: 20.0),
      child: RaisedButton(
        onPressed: () {

          validateAndSubmit();


        },
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(80.0)),
        padding: EdgeInsets.all(0.0),
        child: Ink(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primary.withOpacity(0.7),primary],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(30.0)
          ),
          child: Container(
            constraints: BoxConstraints(
                maxWidth: width * 0.90,
                minHeight: 50.0),
            alignment: Alignment.center,
            child: Text(
              SET_PASSWORD,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headline6.copyWith(color: white,
                  fontWeight: FontWeight.normal),
            ),
          ),
        ),
      ),
    );

  }



  expandedBottomView()
  {
    return Expanded(
        flex:1,
        child:Container(
            width: double.infinity,
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.only(top: 40.0),
                    child: Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)
                      ),
                      margin: EdgeInsets.all(20.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [

                          forgotpassTxt(),
                          setPass(),
                          setConfirmpss(),
                          setPassBtn(),


                        ],
                      ),
                    ),
                  ),
                ],
              ),


            )


        )
    );
  }


  @override
  Widget build(BuildContext context) {

    return Scaffold(
        key: _scaffoldKey,
        body:Form(
            key: _formkey,
            child: Container(
                decoration: back(),
                child: Center(

                    child:Column(
                      children: <Widget>[
                        subLogo(),
                        expandedBottomView(),


                      ],
                    )
                )
            )
        )
    );
  }
}
