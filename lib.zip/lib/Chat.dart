import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:eshop/Helper/Session.dart';
import 'package:eshop/Helper/String.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'Helper/Color.dart';
import 'Helper/Constant.dart';

class Chat extends StatefulWidget {
  final String id;
  const Chat({Key key, this.id}) : super(key: key);

  @override
  _ChatState createState() => _ChatState();
}

class _ChatState extends State<Chat> {
  TextEditingController msgController = new TextEditingController();
  List<File> files = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: getAppBar(getTranslated(context, 'CHAT'), context),
      body: Stack(
        children: <Widget>[
          Align(
            alignment: Alignment.bottomLeft,
            child: Container(
              padding: EdgeInsets.only(left: 10, bottom: 10, top: 10),
              height: 60,
              width: double.infinity,
              color: Colors.white,
              child: Row(
                children: <Widget>[
                  GestureDetector(
                    onTap: () {
                      _imgFromGallery();
                    },
                    child: Container(
                      height: 30,
                      width: 30,
                      decoration: BoxDecoration(
                        color: colors.primary,
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Icon(
                        Icons.add,
                        color: colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Expanded(
                    child: TextField(
                      controller: msgController,
                      decoration: InputDecoration(
                          hintText: "Write message...",
                          hintStyle: TextStyle(color: colors.lightBlack),
                          border: InputBorder.none),
                    ),
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  FloatingActionButton(
                    onPressed: () {
                      if (msgController.text.trim().length > 0)
                        sendMessage(msgController.text.trim());
                    },
                    child: Icon(
                      Icons.send,
                      color: colors.white,
                      size: 18,
                    ),
                    backgroundColor: colors.primary,
                    elevation: 0,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  _imgFromGallery() async {
    FilePickerResult result =
        await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result != null) {
      files = result.paths.map((path) => File(path)).toList();
      if (mounted) setState(() {});
    } else {
      // User canceled the picker
    }
  }

  Future<void> sendMessage(String message) async {
    //   try {
    //     var data = {
    //       USER_ID: CUR_USERID,
    //       TICKET_ID: widget.id,
    //       USER_TYPE: USER,
    //       MESSAGE: msg,
    //     };

    //     Response response = await post(sendMsgApi, body: data, headers: headers)
    //         .timeout(Duration(seconds: timeOut));
    //     print("res***${response.body.toString()}");
    //     if (response.statusCode == 200) {
    //       var getdata = json.decode(response.body);

    //       bool error = getdata["error"];
    //       String msg = getdata["message"];

    //       if (mounted) setState(() {});

    //       // setSnackbar(msg);
    //     }
    //   } on TimeoutException catch (_) {
    //     //  setSnackbar(getTranslated(context, 'somethingMSg'));
    //   }
    // }

    var request = http.MultipartRequest("POST", sendMsgApi);
    request.headers.addAll(headers);
    request.fields[USER_ID] = CUR_USERID;
    request.fields[TICKET_ID] = widget.id;
    request.fields[USER_TYPE] = USER;
    request.fields[MESSAGE] = message;

    if (files != null) {
      for (int i = 0; i < files.length; i++) {
        var pic = await http.MultipartFile.fromPath(IMGS, files[i].path);
        request.files.add(pic);
      }
    }

    var response = await request.send();
    var responseData = await response.stream.toBytes();
    var responseString = String.fromCharCodes(responseData);
    var getdata = json.decode(responseString);
    bool error = getdata["error"];
    String msg = getdata['message'];
    // if (!error) {
    //   setSnackbar(msg);
    // } else {
    //   setSnackbar(msg);
    //   initialRate = 0;
    // }
 print("res***${responseString.toString()}");
    msgController.text = "";
    files.clear();
    if (mounted)
      setState(() {
        //  _isProgress = false;
      });
  }
}
