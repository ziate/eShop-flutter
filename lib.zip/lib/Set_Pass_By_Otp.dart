import 'dart:async';
import 'dart:convert';
import 'package:eshop/Helper/Constant.dart';
import 'package:eshop/Set_Password.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:eshop/Home.dart';
import 'package:flutter/painting.dart';
import 'package:http/http.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'Helper/Color.dart';
import 'Helper/Session.dart';
import 'Helper/String.dart';

class Set_Pass_By_Otp extends StatefulWidget {
  final String mobileNumber,countrycode;

  Set_Pass_By_Otp({
    Key key,
    @required this.mobileNumber,this.countrycode,
  })  : assert(mobileNumber != null),
        super(key: key);

  @override
  _MobileOTPState createState() => new _MobileOTPState();
}

class _MobileOTPState extends State<Set_Pass_By_Otp> with TickerProviderStateMixin {
  String mobile, name, email, password;
  String otp;
  bool isCodeSent = false;
  String _verificationId;
  //bool _isLoading = false;
  bool _isClickable = false;
  String signature = "";
  final otpController = TextEditingController();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  Animation buttonSqueezeanimation;
  AnimationController buttonController;


  @override
  void initState() {
    super.initState();
    _onVerifyCode();
    getUserDetails();
    getSingature();
    Future.delayed(Duration(seconds: 60)).then((_) {
      _isClickable = true;
    });
    buttonController = new AnimationController(
        duration: new Duration(milliseconds: 2000), vsync: this);

    buttonSqueezeanimation = new Tween(
      begin: deviceWidth * 0.7,
      end: 50.0,
    ).animate(new CurvedAnimation(
      parent: buttonController,
      curve: new Interval(
        0.0,
        0.150,
      ),
    ));

  }

  getUserDetails() async {
    mobile = await getPrefrence(MOBILE);
    setState(() {});
  }

  setSnackbar(String msg) {
    _scaffoldKey.currentState.showSnackBar(new SnackBar(
      content: new Text(
        msg,
        textAlign: TextAlign.center,
        style: TextStyle(color: black),
      ),
      backgroundColor: white,
      elevation: 1.0,
    ));
  }

  Future<void> getSingature() async {
    signature = await SmsAutoFill().getAppSignature;
    await SmsAutoFill().listenForCode;
  }

  Future<void> checkNetworkOtp() async {
    bool avail = await isNetworkAvailable();
    if (avail) {
      if (_isClickable) {
        _playAnimation();
        _onVerifyCode();
      }else {
        setSnackbar('Request new OTP after 60 seconds');
      }
    } else {
      setSnackbar(internetMsg);

      Future.delayed(Duration(seconds: 60)).then((_) async {
        bool avail = await isNetworkAvailable();
        if (avail) {
          if (_isClickable)
            _onVerifyCode();
          else {
            setSnackbar('Request new OTP after 60 seconds');
          }
        } else {
          /*    setState(() {
            _isLoading = false;
          });*/
          await buttonController.reverse();
          setSnackbar(somethingMSg);
        }
      });
    }
  }

  void _onVerifyCode() async {
    setState(() {
      isCodeSent = true;
    });
    final PhoneVerificationCompleted verificationCompleted =
        (AuthCredential phoneAuthCredential) {
      _firebaseAuth
          .signInWithCredential(phoneAuthCredential)
          .then((UserCredential value) {
        if (value.user != null) {
          setSnackbar("OTP verified successfully");
          Future.delayed(Duration(seconds: 1)).then((_) {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        SetPass(
                          mobileNumber: widget.mobileNumber,
                        )));
          });
        } else {
          setSnackbar("Error validating OTP, try again");
        }
      }).catchError((error) {
        setSnackbar("Try again in sometime");
      });
    };
    final PhoneVerificationFailed verificationFailed =
        (FirebaseAuthException authException) {
      setSnackbar(authException.message);
      print(authException.message);
      setState(() {
        isCodeSent = false;
      });
    };

    final PhoneCodeSent codeSent =
        (String verificationId, [int forceResendingToken]) async {
      _verificationId = verificationId;
      setState(() {
        setSnackbar("OTP sent successfully");
        _verificationId = verificationId;
      });
    };
    final PhoneCodeAutoRetrievalTimeout codeAutoRetrievalTimeout =
        (String verificationId) {
      _verificationId = verificationId;
      setState(() {
        _verificationId = verificationId;
      });
    };

    await _firebaseAuth.verifyPhoneNumber(
        phoneNumber: "+${widget.countrycode}${widget.mobileNumber}",
        timeout: const Duration(seconds: 60),
        verificationCompleted: verificationCompleted,
        verificationFailed: verificationFailed,
        codeSent: codeSent,
        codeAutoRetrievalTimeout: codeAutoRetrievalTimeout);
  }

  void _onFormSubmitted() async {
    final code = otp.trim();
    AuthCredential _authCredential = PhoneAuthProvider.credential(
        verificationId: _verificationId, smsCode: code);

    _firebaseAuth
        .signInWithCredential(_authCredential)
        .then((UserCredential value) {
      if (value.user != null) {
        setSnackbar("OTP verified successfully");

        Future.delayed(Duration(seconds: 1 )).then((_) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    SetPass(
                      mobileNumber: widget.mobileNumber,
                    )),
          );
        });
      } else {
        setSnackbar("Error validating OTP, try again");
      }
    }).catchError((error) {

      print("error***${error.toString()}");
      setSnackbar("Invalid otp");
    });
  }

  getImage() {
    return Container(
      padding: EdgeInsets.only(top: 100.0),
      child: Center(
        child: new Image.asset('assets/images/homelogo.png', width: 200),
      ),
    );
  }

  monoVarifyText() {
    return Padding(
        padding: EdgeInsets.only(top: 70.0, left: 20.0, right: 20.0),
        child: Center(
          child: new Text(
            MOBILE_NUMBER_VARIFICATION,
            style: Theme.of(context).textTheme.headline6.copyWith(
              color: fontColor,
            ),
          ),
        ));
  }

  otpText() {
    return Container(
        padding: EdgeInsets.only(top: 50.0, left: 20.0, right: 20.0),
        child: Align(
          alignment: Alignment.center,
          child: new Text(
            ENTER_YOUR_OTP_SENT_TO,
            style: Theme.of(context).textTheme.headline6.copyWith(
              color: fontColor,
            ),
          ),
        ));
  }

  mobText() {
    return Padding(
      padding:
      EdgeInsets.only(bottom: 20.0, left: 20.0, right: 20.0, top: 10.0),
      child: Center(
        child: Text(
          "+${widget.countrycode}$mobile",
          style: Theme.of(context).textTheme.headline6.copyWith(
            color: fontColor,
          ),
        ),
      ),
    );
  }

  Future<Null> _playAnimation() async {
    try {
      await buttonController.forward();
    } on TickerCanceled {}
  }

  otpLayout() {
    return Padding(
        padding: EdgeInsets.only(left: 80.0, right: 80.0, top: 30.0),
        child: Center(
          child: PinFieldAutoFill(
              decoration: UnderlineDecoration(
                textStyle: TextStyle(fontSize: 20, color: black),
                colorBuilder: FixedColorBuilder(fontColor),
              ),
              codeLength: 6,
              currentCode: otp,
              onCodeChanged: (String code) {
                otp = code;
              },
              onCodeSubmitted: (String code) {
                otp = code;
              }),
        ));
  }

  verifyBtn() {
    return
      new AnimatedBuilder(
        builder: _buildBtnAnimation,
        animation: buttonSqueezeanimation,
      );
  }
  Widget _buildBtnAnimation(BuildContext context, Widget child) {
    return CupertinoButton(
      child: Container(
        width: buttonSqueezeanimation.value,
        height: 45,
        alignment: FractionalOffset.center,
        decoration: new BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [secondary, primary],
              stops: [0, 1]),

          borderRadius: new BorderRadius.all(const Radius.circular(50.0)),
        ),
        child: buttonSqueezeanimation.value > 75.0
            ? Text(VERIFY_AND_PROCEED,
            textAlign: TextAlign.center,
            style: Theme
                .of(context)
                .textTheme
                .headline6
                .copyWith(color: white, fontWeight: FontWeight.normal))
            : new CircularProgressIndicator(
          valueColor: new AlwaysStoppedAnimation<Color>(white),
        ),
      ),

      onPressed: () {
        if (otp.length == 6) {
          _onFormSubmitted();
        } else {
          setSnackbar("Invalid OTP");
        }
      },
    );
  }

  resendText() {
    return Padding(
      padding:
      EdgeInsets.only(bottom: 20.0, left: 20.0, right: 20.0, top: 25.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            DIDNT_GET_THE_CODE,
            style: Theme.of(context).textTheme.bodyText1.copyWith(
              color: fontColor,
            ),
          ),
          InkWell(
              onTap: () {
                checkNetworkOtp();
              },
              child: Text(
                RESEND_OTP,
                style: Theme.of(context).textTheme.bodyText1.copyWith(
                    color: primary, decoration: TextDecoration.underline),
              ))
        ],
      ),
    );
  }

  expandedBottomView() {
    double width = deviceWidth;
    return Expanded(
        child: Container(
            width: double.infinity,
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Container(
                    width: width,
                    padding: EdgeInsets.only(top: 50.0),
                    child: Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      margin: EdgeInsets.all(20.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          monoVarifyText(),
                          otpText(),
                          mobText(),
                          otpLayout(),
                          verifyBtn(),
                          resendText(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        body: Container(
            decoration: back(),
            child: Center(
              child: Column(
                children: <Widget>[
                  getImage(),
                  expandedBottomView(),
                ],
              ),
            )));
  }
}
