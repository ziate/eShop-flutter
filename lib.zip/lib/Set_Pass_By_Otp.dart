import 'dart:async';
import 'dart:convert';
import 'package:eshop/Helper/Constant.dart';
import 'package:eshop/Set_Password.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:eshop/Home.dart';
import 'package:flutter/painting.dart';
import 'package:http/http.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'Helper/Color.dart';
import 'Helper/Session.dart';
import 'Helper/String.dart';

class Set_Pass_By_Otp extends StatefulWidget {
  final String mobileNumber;

  Set_Pass_By_Otp({
    Key key,
    @required this.mobileNumber,
  })  : assert(mobileNumber != null),
        super(key: key);

  @override
  _MobileOTPState createState() => new _MobileOTPState();
}

class _MobileOTPState extends State<Set_Pass_By_Otp> {
  String mobile, name, email, password;
  String otp;
  bool isCodeSent = false;
  String _verificationId;
  bool _isLoading = false;
  bool _isClickable = false;
  String signature = "";
  final otpController = TextEditingController();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _onVerifyCode();
    getUserDetails();
    getSingature();
    Future.delayed(Duration(seconds: 60)).then((_) {
      _isClickable = true;
    });
  }

  getUserDetails() async {
    mobile = await getPrefrence(MOBILE);
    setState(() {});
  }

  setSnackbar(String msg) {
    _scaffoldKey.currentState.showSnackBar(new SnackBar(
      content: new Text(
        msg,
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.black),
      ),
      backgroundColor: Colors.white,
      elevation: 1.0,
    ));
  }

  Future<void> getSingature() async {
    signature = await SmsAutoFill().getAppSignature;
    await SmsAutoFill().listenForCode;
  }

  Future<void> checkNetworkOtp() async {
    bool avail = await isNetworkAvailable();
    if (avail) {
      if (_isClickable)
        _onVerifyCode();
      else {
        setSnackbar('Request new OTP after 60 seconds');
      }
    } else {
      setSnackbar(internetMsg);

      Future.delayed(Duration(seconds: 60)).then((_) async {
        bool avail = await isNetworkAvailable();
        if (avail) {
          if (_isClickable)
            _onVerifyCode();
          else {
            setSnackbar('Request new OTP after 60 seconds');
          }
        } else {
          setState(() {
            _isLoading = false;
          });
          setSnackbar(somethingMSg);
        }
      });
    }
  }



  void _onVerifyCode() async {

    setState(() {
          isCodeSent = true;
    });
    final PhoneVerificationCompleted verificationCompleted =
        (AuthCredential phoneAuthCredential) {
      _firebaseAuth
          .signInWithCredential(phoneAuthCredential)
          .then((UserCredential value) {
        if (value.user != null) {
          //checkNetwork();
          //setPrefrence(MOBILE,mobile);
          Navigator.push(
              context,
              MaterialPageRoute(
              builder: (context) =>
              SetPass(mobileNumber: widget.mobileNumber,)));

        } else {
          setSnackbar("Error validating OTP, try again");
        }
      }).catchError((error) {
        setSnackbar("Try again in sometime");
      });
    };
    final PhoneVerificationFailed verificationFailed =
        (FirebaseAuthException authException) {
      setSnackbar(authException.message);
      print(authException.message);
      setState(() {
        isCodeSent = false;
      });
    };

    final PhoneCodeSent codeSent =
        (String verificationId, [int forceResendingToken]) async {
      _verificationId = verificationId;
      setState(() {
        _verificationId = verificationId;
      });
    };
    final PhoneCodeAutoRetrievalTimeout codeAutoRetrievalTimeout =
        (String verificationId) {
      _verificationId = verificationId;
      setState(() {
        _verificationId = verificationId;
      });
    };

    await _firebaseAuth.verifyPhoneNumber(
        phoneNumber: "+${widget.mobileNumber}",
        timeout: const Duration(seconds: 60),
        verificationCompleted: verificationCompleted,
        verificationFailed: verificationFailed,
        codeSent: codeSent,
        codeAutoRetrievalTimeout: codeAutoRetrievalTimeout);
  }

  void _onFormSubmitted() async {
    final code = otp.trim();
    AuthCredential _authCredential = PhoneAuthProvider.getCredential(
        verificationId: _verificationId, smsCode: code);

    _firebaseAuth
        .signInWithCredential(_authCredential)
        .then((UserCredential value) {
      if (value.user != null) {

          //setPrefrence(MOBILE,mobile);
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    SetPass(mobileNumber: widget.mobileNumber,)),
          );


      } else {
        setSnackbar("Error validating OTP, try again");
      }
    }).catchError((error) {
      setSnackbar("Something went wrong");
    });
  }

  getImage() {
    return Container(
      padding: EdgeInsets.only(top: 100.0),
      child: Center(
        child: new Image.asset('assets/images/sublogo.png', width: 200),
      ),
    );
  }

  monoVarifyText() {
    return Padding(
        padding: EdgeInsets.only(top: 70.0, left: 20.0, right: 20.0),
        child: Center(
          child: new Text(
            MOBILE_NUMBER_VARIFICATION,
            style: Theme.of(context).textTheme.headline6.copyWith(color: lightblack,),
          ),
        ));
  }

  otpText() {
    return Container(
        padding: EdgeInsets.only(top: 50.0, left: 20.0, right: 20.0),
        child: Align(
          alignment: Alignment.center,
          child: new Text(
            ENTER_YOUR_OTP_SENT_TO,
            style: Theme.of(context).textTheme.headline6.copyWith(color: lightblack,),
          ),
        ));
  }

  mobText() {
    return Padding(
      padding: EdgeInsets.only(bottom: 20.0, left: 20.0, right: 20.0, top: 10.0),
      child: Center(
          child:Text("+$mobile",
              style: Theme.of(context).textTheme.headline6.copyWith(color: lightblack,),),
      ),
    );
  }

  otpLayout() {
    return Padding(
        padding: EdgeInsets.only(left: 80.0, right: 80.0, top: 30.0),
        child: Center(
          child: PinFieldAutoFill(
              codeLength: 6,
              currentCode: otp,
              onCodeChanged: (String code) {
                otp = code;
              },
              onCodeSubmitted: (String code) {
                otp = code;

              }
          ),

    ));
  }

  verifyBtn() {
    double width = MediaQuery.of(context).size.width;

    return Padding(
      padding:
      EdgeInsets.only(bottom: 10.0, left: 20.0, right: 20.0, top: 60.0),
      child: RaisedButton(
        onPressed: () {
          if (otp.length == 6) {
            _onFormSubmitted();
          } else {
            setSnackbar("Invalid OTP");
          }
        },
        shape:
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(80.0)),
        padding: EdgeInsets.all(0.0),
        child: Ink(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.lightBlue, Colors.blue],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(30.0)),
          child: Container(
            constraints:
            BoxConstraints(maxWidth: width * 0.90, minHeight: 50.0),
            alignment: Alignment.center,
            child: Text(
              VERIFY_AND_PROCEED,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headline6.copyWith(color: white),
            ),
          ),
        ),
      ),
    );
  }

  resendText() {
    return Padding(
      padding:
      EdgeInsets.only(bottom: 20.0, left: 20.0, right: 20.0, top: 25.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(DIDNT_GET_THE_CODE,
              style:Theme.of(context).textTheme.subhead.copyWith(color: lightblack2,),),
          InkWell(
              onTap: () {
               checkNetworkOtp();
              },
              child: Text(
                RESEND_OTP,
                style:Theme.of(context).textTheme.subhead.copyWith(color: primary, decoration: TextDecoration.underline),
              ))
        ],
      ),
    );
  }

  expandedBottomView() {
    double width = MediaQuery.of(context).size.width;
    return Expanded(
        flex: 1,
        child: Container(
            width: double.infinity,
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Container(
                    width: width,
                    padding: EdgeInsets.only(top: 50.0),
                    child: Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      margin: EdgeInsets.all(20.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          monoVarifyText(),
                          otpText(),
                          mobText(),
                          otpLayout(),
                          verifyBtn(),
                          resendText(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        body:  Container(
            decoration: back(),
            child: Center(
              child: Column(
                children: <Widget>[
                  getImage(),
                  expandedBottomView(),
                ],
              ),
            )));
  }
}
