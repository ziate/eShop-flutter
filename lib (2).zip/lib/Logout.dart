import 'package:eshop/Helper/Color.dart';
import 'package:eshop/Helper/String.dart';
import 'package:eshop/Intro_Slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Helper/Constant.dart';
import 'Helper/Session.dart';
import 'Helper/String.dart';
import 'Login.dart';
import 'Model/User.dart';

class Logout extends StatefulWidget {
  final String title;

  const Logout({Key key, this.title}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return StateLogout();
  }
}

class StateLogout extends State<Logout> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: getAppBar(widget.title, context),
        backgroundColor: lightBlack2,
        body: CupertinoAlertDialog(
            title: Text(
              LOGOUTTXT,
              style: Theme.of(context).textTheme.headline6.copyWith(
                    color: lightBlack,
                  ),
              textAlign: TextAlign.center,
            ),
            actions: [
              CupertinoDialogAction(
                  child: Text(
                    LOGOUTNO,
                    style: Theme.of(context)
                        .textTheme
                        .headline6
                        .copyWith(color: primary),
                    textAlign: TextAlign.center,
                  ),
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  }),
              CupertinoDialogAction(
                  child: Text(
                    LOGOUTYES,
                    style: Theme.of(context)
                        .textTheme
                        .headline6
                        .copyWith(color: primary),
                    textAlign: TextAlign.center,
                  ),
                  onPressed: () {
                    clearUserSession();
                    Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                            builder: (BuildContext context) => Login()),
                        ModalRoute.withName('/'));
                  }),
            ]));
  }
}
