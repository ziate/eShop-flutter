final String appName = 'eShop';

final String packageName = 'com.wrteam.eshop';
final String androidLink = 'https://play.google.com/store/apps/details?id=';

final String iosPackage = 'com.wrteam.eshop';
final String iosLink = 'your ios link here';
final String appStoreId = '123456789';

final String deepLinkUrlPrefix = 'https://eshopwrteamin.page.link';
final String deepLinkName = 'eshop';

final String baseUrl = 'https://eshopweb.store/app/v1/api/';
//final String baseUrl = 'https://sifbasket.com/app/v1/api/';

final int timeOut = 50;
const int perPage = 10;
final String jwtKey = "68f05dec6014f68e760c5c5fa3e31bcf391a2e10";
//final String jwtKey = "9e35dc5fd1403e1f12cebbbe1418cf16ffe6bfff";